package com.example.notify_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
